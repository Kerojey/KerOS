void init_video_mode(void);
void print(void);
void end(void);
void sleep(void);